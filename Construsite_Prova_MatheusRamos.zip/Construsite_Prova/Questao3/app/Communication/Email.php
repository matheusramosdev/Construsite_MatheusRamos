<?php

namespace App\Communication;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

class Email
{

    /**
     * Credencial Acesso SMTP
     * @var string
     */

    const HOST = 'smtp.gmail.com';
    const USER = 'exemplo@gmail.com';
    const PASS = 'senha123';
    const SECURE = 'TLS';
    const PORT = 587;
    const CHARSET = 'UTF-8';

    /**
     * DADOS ENVIO
     * @var string
     */

    const FROM_EMAIL = 'exemplo@gmail.com';
    const FROM_NAME = 'Matheus Ramos';

    /**
     * Mensagem Error
     * @var string
     */

    private $error;

    /**
     * Método de retorno de erro
     * @return string
     */

    public function getError()
    {
        return $this->error;
    }

    public function sendEmail($email, $conteudo_email)
    {
        $this->error = '';

        $obMail = new PHPMailer(true);
        try {

            $obMail->isSMTP(true);
            $obMail->Host = self::HOST;
            $obMail->SMTPAuth = true;
            $obMail->Username = self::USER;
            $obMail->Password = self::PASS;
            $obMail->SMTPSecure = self::SECURE;
            $obMail->Port = self::PORT;
            $obMail->Charset = self::CHARSET;

            $obMail->setFrom(self::FROM_EMAIL, self::FROM_NAME);

            $email = is_array($email) ? $email : [$email];
            foreach ($email as $emails) {
                $obMail->addAddress($emails);
            }

            $obMail->isHTML(true);
            $obMail->Subject = 'Questao 3';
            $obMail->Body = $conteudo_email;

            return $obMail->send();
        } catch (PHPMailerException $e) {
            $this->error = $e->getmessage();
            return false;
        }
    }
}
