<?php

require __DIR__ . '/vendor/autoload.php';

use \App\Communication\Email;

$email_destino = 'exemplo@gmail.com';

$nome = utf8_encode($_POST['nome']);
$telefone = utf8_encode($_POST['telefone']);
$email = utf8_encode($_POST['email']);
$mensagem = utf8_encode($_POST['mensagem']);

$conteudo_email = "
Uma mensagem foi enviada de: $nome
<br>
E-mail: $email
<br>
Telefone: $telefone
<br><br>
Mensagem:<br>
$mensagem
";

$obEmail = new Email;
$sucesso = $obEmail->sendEmail($email_destino, $conteudo_email);

echo $sucesso ? 'Mensagem enviada!' : $obMail->getError();
