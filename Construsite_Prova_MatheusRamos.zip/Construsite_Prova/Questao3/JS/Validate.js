const button = document.getElementById('Enviar')

button.addEventListener('click', (event) => {

    const nome = document.getElementById('nome')
    const telefone = document.getElementById('telefone')
    const email = document.getElementById('email')
    const mensagem = document.getElementById('mensagem')

    if (nome.value == '') {
        alert("Erro! O campo 'Nome' não pode estar vazio.")
        event.preventDefault()
    }
    if (telefone.value == '') {
        alert("Erro! O campo 'Telefone' não pode estar vazio.")
        event.preventDefault()
    }
    if (email.value == '') {
        alert("Erro! O campo 'E-mail' não pode estar vazio.")
        event.preventDefault()
    }
    if (mensagem.value == '') {
        alert("Erro! O campo 'Mensagem' não pode estar vazio.")
        event.preventDefault()
    }

    if (email.value.indexOf("@") == -1 || email.value.indexOf(".") == -1 || (email.value.indexOf(".") - email.value.indexOf("@") == 1)) {
        alert("Erro! O campo 'Email' não apresenta um valor válido. Exemplo -> teste@mail.com")
        event.preventDefault()
    }
    if (telefone.value.length <= 8) {
        alert("Erro! O campo 'Telefone' não apresenta um valor válido.")
        event.preventDefault()
    }

})